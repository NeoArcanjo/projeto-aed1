using System;

class Util {
  
  public static void write(string texto){
    Console.WriteLine(texto);
  }
  public static string read(){
    return Console.ReadLine();
  }
}
