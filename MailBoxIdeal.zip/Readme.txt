
* Menu MailBOX.ideal*
cadastro usuario (sem réplicas)
login usuario

* Menu Usuario *
abrir (propria) MailBOX (ler mensagens)
enviar MailBOX (escrever mensagens) (parâmetro: destinatário)
limpar MailBOX
deslogar